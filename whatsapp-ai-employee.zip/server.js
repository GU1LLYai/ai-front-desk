import express from "express";
import dotenv from "dotenv";
import twilio from "twilio";
import { google } from "googleapis";
import { getClientByPhone, saveClientTokens } from "./lib/clients.js";
import { runAgent } from "./lib/claude.js";

dotenv.config();

const app = express();
app.use(express.urlencoded({ extended: false })); // Twilio sends form-encoded webhooks
app.use(express.json());

const twilioClient = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

// --- Customer sends a WhatsApp/SMS message to a client's business number ---
app.post("/webhook/whatsapp", async (req, res) => {
  const from = req.body.From; // customer's number, e.g. "whatsapp:+447700900000"
  const to = req.body.To; // the business's number the customer texted
  const body = req.body.Body;

  res.status(200).send(); // acknowledge Twilio immediately, reply is sent separately below

  const client = getClientByPhone(to);
  if (!client) {
    console.error(`No client configured for number ${to}`);
    return;
  }

  try {
    const reply = await runAgent({ client, customerPhone: from, message: body });
    await twilioClient.messages.create({ from: to, to: from, body: reply });
  } catch (err) {
    console.error("Agent error:", err);
    await twilioClient.messages.create({
      from: to,
      to: from,
      body: "Sorry, something went wrong on our end — please try again shortly.",
    });
  }
});

// --- One-time setup: business owner connects their Google Calendar ---
// Send each new client to: /auth/google?clientId=their-client-id
app.get("/auth/google", (req, res) => {
  const { clientId } = req.query;
  const oauth2 = getOAuthClient();
  const url = oauth2.generateAuthUrl({
    access_type: "offline",
    prompt: "consent",
    scope: ["https://www.googleapis.com/auth/calendar"],
    state: clientId, // carries your internal client id through the OAuth round trip
  });
  res.redirect(url);
});

app.get("/auth/google/callback", async (req, res) => {
  const { code, state } = req.query;
  const oauth2 = getOAuthClient();
  const { tokens } = await oauth2.getToken(code);
  saveClientTokens(state, tokens);
  res.send("Calendar connected — you can close this window.");
});

function getOAuthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`AI front desk backend listening on port ${port}`));
