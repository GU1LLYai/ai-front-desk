# AI Front Desk — WhatsApp/SMS backend

Receives customer texts on a business's number, answers using that business's
own info, and books real appointments straight onto their Google Calendar.

## How it fits together

```
Customer texts business number
        │
        ▼
   Twilio webhook  →  server.js  →  lib/claude.js (asks Claude, using
        │                            that client's info as context)
        │                                  │
        │                                  ▼
        │                          lib/calendar.js (checks/writes
        │                           the business's real calendar)
        ▼
   Reply texted back to customer
```

## 1. Install

```
npm install
cp .env.example .env
```

Fill in `.env`:
- `ANTHROPIC_API_KEY` — from console.anthropic.com
- `TWILIO_ACCOUNT_SID` / `TWILIO_AUTH_TOKEN` — from your Twilio console
- `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — from a Google Cloud project
  with the Calendar API enabled (APIs & Services → Credentials → OAuth
  client ID → "Web application")
- `GOOGLE_REDIRECT_URI` — must exactly match a redirect URI you added to
  that OAuth client, e.g. `https://yourdomain.com/auth/google/callback`

## 2. Run it

```
npm start
```

This needs to be reachable over HTTPS for Twilio and Google to call it —
use a host like Render, Railway, or Fly.io, or `ngrok http 3000` while
testing locally.

## 3. Connect Twilio

- Get a WhatsApp-enabled Twilio number (or use their sandbox number while
  testing)
- In the Twilio console, set the WhatsApp webhook for incoming messages to:
  `https://yourdomain.com/webhook/whatsapp`

## 4. Onboard a new client (business)

This is now fully self-serve — no editing JSON by hand:

1. Send the business owner to `https://yourdomain.com/onboard`.
2. They fill in their business name, hours, prices, and FAQs, and submit.
   This writes their client file automatically (see `lib/clients.js`).
3. They're redirected straight into Google's sign-in to connect their own
   calendar — once approved, they land on a "you're all set" confirmation
   page.
4. Done — texts to their number now get answered with their info, and
   bookings land on their real calendar.

Note: they still need a Twilio number provisioned for their business before
this step (see #3 above) — the form asks for it rather than creating it,
since buying/configuring numbers happens in the Twilio console or via
Twilio's API if you want to automate that too.

`clients/example-client.json` is left in place as a reference for the
shape of a client file, in case you want to seed one manually for testing.

## Notes on going from here to production

- **Storage**: client info currently lives in flat JSON files
  (`lib/clients.js`) — fine for a handful of clients, but swap for a real
  database once you have more, since concurrent writes to JSON files
  aren't safe.
- **Security**: Google tokens are currently stored in plain JSON on disk —
  encrypt these at rest before handling real client data.
- **Multiple businesses, one Twilio number**: right now each client needs
  their own Twilio number so incoming texts can be routed to the right
  client. An alternative is one shared number with a bot-style opt-in
  ("text START to talk to Example Hair Studio"), but a dedicated number
  per client is simpler and feels more like "their own employee."
